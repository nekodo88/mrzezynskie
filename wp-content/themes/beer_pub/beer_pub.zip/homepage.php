<?php 
/**
Template Name: Home
*/
get_header();

get_template_part('part-templates/home-about');
get_template_part('part-templates/home-services');
get_template_part('part-templates/home-thepub');
get_template_part('part-templates/home-ourbrewery');
get_template_part('part-templates/home-rates');
get_template_part('part-templates/home-blog');
get_template_part('part-templates/home-contact');

get_footer(); ?> 