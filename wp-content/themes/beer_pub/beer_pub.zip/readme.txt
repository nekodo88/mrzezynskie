=== beer_pub ===
Requires at least: WordPress 4.5
Tested up to: WordPress 4.9.4
Version: 1.0
License: 
License URI: 
Tags: one-column, two-columns, right-sidebar, custom-menu, editor-style, featured-images, flexible-header, full-width-template, microformats, post-formats, sticky-post, theme-options, translation-ready

== Changelog ==

Initial release
